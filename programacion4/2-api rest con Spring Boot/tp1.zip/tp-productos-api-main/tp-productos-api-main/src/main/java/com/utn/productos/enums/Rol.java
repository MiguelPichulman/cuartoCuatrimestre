package com.utn.productos.enums;

public enum Rol {
    ADMIN, USUARIO;
}
