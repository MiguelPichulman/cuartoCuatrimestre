package com.utn.productos.enums;

public enum Estado {
    PENDIENTE, CONFIRMADO, TERMINADO, CANCELADO;
}
