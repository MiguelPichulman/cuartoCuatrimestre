package com.utn.productos.service;
import com.utn.productos.dto.ProductoDTO;
import com.utn.productos.dto.ProductoResponseDTO;
import com.utn.productos.exception.ProductoNotFoundException;
import com.utn.productos.exception.StockInsuficienteException;
import com.utn.productos.model.Categoria;
import com.utn.productos.model.Producto;
import com.utn.productos.repository.CategoriaRepository;
import com.utn.productos.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Servicio que contiene la lógica de negocio para la gestión de productos.
 * Actúa como intermediario entre el controller y el repository.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class ProductoService {

    private final ProductoRepository productoRepository;
    // Agregamos el repositorio de categoría para poder vincularla
    private final CategoriaRepository categoriaRepository;

    /**
     * Crea un nuevo producto en el sistema.
     */
    public ProductoResponseDTO crearProducto(ProductoDTO productoDTO) {
        // 1. Buscamos la categoría por ID
        Categoria categoria = categoriaRepository.findById(productoDTO.getCategoriaId())
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + productoDTO.getCategoriaId()));

        // 2. Convertir DTO a entidad
        Producto producto = productoDTO.toEntity();

        // NO TE OLVIDES DE ESTO: Si en el UML usás relaciones bidireccionales,
        // acá deberías setear la categoría en el producto.
        // Si no lo tenés mapeado bidireccionalmente, Spring lo maneja igual al guardar.

        // 3. Guardar en base de datos
        Producto productoGuardado = productoRepository.save(producto);

        return ProductoResponseDTO.fromEntity(productoGuardado);
    }

    /**
     * Obtiene todos los productos del sistema (que no estén eliminados).
     */
    @Transactional(readOnly = true)
    public List<ProductoResponseDTO> obtenerTodos() {
        return productoRepository.findAll().stream()
                .filter(p -> !p.isEliminado()) // Filtramos los borrados lógicamente
                .map(ProductoResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Busca un producto por su ID.
     */
    @Transactional(readOnly = true)
    public ProductoResponseDTO obtenerPorId(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ProductoNotFoundException(id));

        if (producto.isEliminado()) {
            throw new ProductoNotFoundException(id); // O podrías crear una ProductoEliminadoException
        }

        return ProductoResponseDTO.fromEntity(producto);
    }

    /**
     * Filtra productos por el ID de la categoría.
     * Busca la categoría en la base de datos y devuelve su lista interna de productos.
     */
    @Transactional(readOnly = true)
    public List<ProductoResponseDTO> obtenerPorCategoriaId(Long categoriaId) {
        Categoria categoria = categoriaRepository.findById(categoriaId)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + categoriaId));

        return categoria.getProductos().stream()
                .filter(p -> !p.isEliminado()) // Filtramos los que están borrados lógicamente
                .map(ProductoResponseDTO::fromEntity)
                .collect(java.util.stream.Collectors.toList());
    }

    /**
     * Actualiza completamente un producto existente (operación PUT).
     */
    public ProductoResponseDTO actualizarProducto(Long id, ProductoDTO productoDTO) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ProductoNotFoundException(id));

        // Si mandan un categoriaId distinto, actualizamos la categoría
        if (!productoDTO.getCategoriaId().equals(producto.getId())) { // Suponiendo que producto tiene un getCategoria() en tu implementación real
            Categoria nuevaCategoria = categoriaRepository.findById(productoDTO.getCategoriaId())
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + productoDTO.getCategoriaId()));
            // producto.setCategoria(nuevaCategoria); (Descomentar si tenés este setter en Producto)
        }

        productoDTO.updateEntity(producto);
        Producto productoActualizado = productoRepository.save(producto);

        return ProductoResponseDTO.fromEntity(productoActualizado);
    }

    /**
     * Actualiza solo el stock de un producto (operación PATCH).
     */
    public ProductoResponseDTO actualizarStock(Long id, Integer nuevoStock) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ProductoNotFoundException(id));

        producto.setStock(nuevoStock);
        Producto productoActualizado = productoRepository.save(producto);

        return ProductoResponseDTO.fromEntity(productoActualizado);
    }

    /**
     * Elimina un producto del sistema mediante BORRADO LÓGICO.
     */
    public void eliminarProducto(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ProductoNotFoundException(id));

        if (producto.getStock() > 0) {
            throw new StockInsuficienteException(
                    "No se puede eliminar el producto '" + producto.getNombre() +
                            "' porque tiene stock disponible (" + producto.getStock() + " unidades). " +
                            "Por favor, reduzca el stock a 0 antes de eliminar."
            );
        }

        // CAMBIO CLAVE: Borrado lógico en lugar de físico
        producto.setEliminado(true);
        productoRepository.save(producto);
    }
}