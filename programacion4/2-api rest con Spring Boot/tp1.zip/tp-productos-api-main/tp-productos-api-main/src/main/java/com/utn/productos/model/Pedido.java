package com.utn.productos.model;
import com.utn.productos.enums.Estado;
import com.utn.productos.enums.FormaPago;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Pedido extends Base implements Calculable {
    private LocalDate fecha;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    private Double total=0.0;

    @Enumerated(EnumType.STRING)
    private FormaPago formaPago;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "pedido_id")
    private List<DetallePedido> detalles = new ArrayList<>();

    // --- 1. IMPLEMENTACIÓN DE LA INTERFAZ ---
    @Override
    public void calcularTotal() {
        this.total = 0.0;
        for (DetallePedido detalle : detalles) {
            this.total += detalle.getSubtotal();
        }
    }

    // --- 2. LOS MÉTODOS DEL UML ---

    public void addDetallePedido(int cantidad, Producto producto) {
        DetallePedido detalle = new DetallePedido();
        detalle.setCantidad(cantidad);
        detalle.setProducto(producto);
        detalle.setSubtotal(producto.getPrecio() * cantidad);

        this.detalles.add(detalle);
        this.calcularTotal(); // Recalculamos
    }

    public DetallePedido findDetallePedidoByProducto(Producto producto) {
        return this.detalles.stream()
                .filter(d -> d.getProducto().getId().equals(producto.getId()))
                .findFirst()
                .orElse(null);
    }

    public void deleteDetallePedidoByProducto(Producto producto) {
        DetallePedido detalle = findDetallePedidoByProducto(producto);
        if (detalle != null) {
            // Simplemente lo removemos de la lista
            this.detalles.remove(detalle);

            // Y recalculamos el total del pedido
            this.calcularTotal();
        }
    }


}
