package com.utn.productos.controller;
import com.utn.productos.dto.PedidoDTO;
import com.utn.productos.model.Pedido;
import com.utn.productos.service.PedidoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pedidos")
@RequiredArgsConstructor
public class PedidoController {
    private final PedidoService pedidoService;

    @PostMapping
    public ResponseEntity<Pedido> crearPedido(@Valid @RequestBody PedidoDTO dto) {
        return new ResponseEntity<>(pedidoService.crearPedido(dto), HttpStatus.CREATED);
    }
}
