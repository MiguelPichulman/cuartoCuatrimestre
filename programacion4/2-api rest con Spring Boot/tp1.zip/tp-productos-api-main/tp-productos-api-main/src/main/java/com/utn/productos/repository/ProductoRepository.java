package com.utn.productos.repository;

import com.utn.productos.model.Categoria;
import com.utn.productos.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio JPA para la entidad Producto.
 * Extiende JpaRepository que proporciona métodos CRUD básicos y query methods.
 *
 * JpaRepository<Producto, Long> indica:
 * - Producto: la entidad que gestiona
 * - Long: el tipo de dato de la clave primaria
 *
 * Spring Data JPA genera automáticamente la implementación en tiempo de ejecución.
 */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {


}
