package com.utn.productos.service;
import com.utn.productos.dto.DetallePedidoDTO;
import com.utn.productos.dto.PedidoDTO;
import com.utn.productos.enums.Estado;
import com.utn.productos.model.Pedido;
import com.utn.productos.model.Producto;
import com.utn.productos.model.Usuario;
import com.utn.productos.repository.PedidoRepository;
import com.utn.productos.repository.ProductoRepository;
import com.utn.productos.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class PedidoService {
    private final PedidoRepository pedidoRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductoRepository productoRepository;

    @Transactional
    public Pedido crearPedido(PedidoDTO dto) {
        // 1. Buscamos al usuario (Él es quien conoce sus pedidos)
        Usuario usuario = usuarioRepository.findById(dto.getUsuarioId())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + dto.getUsuarioId()));

        // 2. Instanciamos el pedido
        Pedido pedido = new Pedido();
        pedido.setFecha(LocalDate.now());
        pedido.setEstado(Estado.PENDIENTE);
        pedido.setFormaPago(dto.getFormaPago());

        // 3. Procesamos los detalles
        for (DetallePedidoDTO detalleDTO : dto.getDetalles()) {
            Producto producto = productoRepository.findById(detalleDTO.getProductoId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + detalleDTO.getProductoId()));

            // Validamos el stock
            if (producto.getStock() < detalleDTO.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para: " + producto.getNombre());
            }

            // Descontamos stock y persistimos el cambio
            producto.setStock(producto.getStock() - detalleDTO.getCantidad());
            productoRepository.save(producto);

            // LA MAGIA DE LA ORIENTACIÓN A OBJETOS:
            // Solo pasamos cantidad y producto. La entidad Pedido calcula el subtotal
            // y actualiza su propio total general automáticamente.
            pedido.addDetallePedido(detalleDTO.getCantidad(), producto);
        }

        // 4. VINCULACIÓN UNIDIRECCIONAL
        // Agregamos el pedido listo y calculado a la lista del usuario
        usuario.getPedidos().add(pedido);

        // 5. Guardamos el usuario
        // Por el CascadeType.ALL, JPA guarda el Usuario, inserta el Pedido y sus Detalles en cascada.
        usuarioRepository.save(usuario);

        // Retornamos el último pedido de la lista (el que acabamos de agregar)
        return usuario.getPedidos().get(usuario.getPedidos().size() - 1);
    }
}
