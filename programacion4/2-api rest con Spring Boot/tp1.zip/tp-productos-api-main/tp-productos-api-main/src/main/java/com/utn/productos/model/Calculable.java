package com.utn.productos.model;

public interface Calculable {
    void calcularTotal();
}
