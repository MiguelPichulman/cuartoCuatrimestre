package com.utn.productos.dto;
import com.utn.productos.enums.Rol;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UsuarioDTO {
    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    @NotBlank(message = "El apellido no puede estar vacío")
    private String apellido;

    @NotBlank(message = "El mail es obligatorio")
    @Email(message = "El formato del mail no es válido")
    private String mail;

    @NotBlank(message = "El celular es obligatorio")
    private String celular;

    @NotBlank(message = "La contraseña no puede estar vacía")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String contraseña;

    @NotNull(message = "El rol es obligatorio (ADMIN o USUARIO)")
    private Rol rol;
}
