package com.utn.productos.enums;

public enum FormaPago {
    TARJETA, TRANSFERENCIA, EFECTIVO;
}
