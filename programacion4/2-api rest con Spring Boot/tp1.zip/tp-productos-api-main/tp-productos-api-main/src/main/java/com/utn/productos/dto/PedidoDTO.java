package com.utn.productos.dto;
import com.utn.productos.enums.FormaPago;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class PedidoDTO {
    @NotNull(message = "El ID del usuario es obligatorio")
    private Long usuarioId;

    @NotNull(message = "La forma de pago es obligatoria")
    private FormaPago formaPago;

    @NotEmpty(message = "El pedido debe tener al menos un detalle")
    @Valid // Fundamental para que valide los DetallePedidoDTO por dentro
    private List<DetallePedidoDTO> detalles;
}
