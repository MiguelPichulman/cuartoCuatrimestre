package com.utn.productos.controller;
import com.utn.productos.dto.UsuarioDTO;
import com.utn.productos.model.Usuario;
import com.utn.productos.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {
    private final UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<Usuario> crearUsuario(@Valid @RequestBody UsuarioDTO dto) {
        return new ResponseEntity<>(usuarioService.crearUsuario(dto), HttpStatus.CREATED);
    }

    // Cumple Criterio C2.3: Búsqueda por ID y mostrar por consola
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> buscarPorId(@PathVariable Long id) {
        Usuario usuario = usuarioService.buscarPorId(id);
        System.out.println("Información del Usuario encontrado por ID: " + usuario);
        return ResponseEntity.ok(usuario);
    }

    // Cumple Criterio C2.4: Búsqueda por mail y mostrar por consola
    @GetMapping("/mail/{mail}")
    public ResponseEntity<Usuario> buscarPorMail(@PathVariable String mail) {
        Usuario usuario = usuarioService.buscarPorMail(mail);
        System.out.println("Información del Usuario encontrado por mail: " + usuario);
        return ResponseEntity.ok(usuario);
    }

}
