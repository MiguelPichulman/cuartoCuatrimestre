package com.utn.productos.repository;

import com.utn.productos.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    // punto 8 del TP
    Optional<Usuario> findByMail(String mail);
    
}
