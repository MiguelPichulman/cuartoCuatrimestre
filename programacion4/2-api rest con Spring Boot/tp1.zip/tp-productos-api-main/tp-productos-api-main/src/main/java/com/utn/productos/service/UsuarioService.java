package com.utn.productos.service;
import com.utn.productos.dto.UsuarioDTO;
import com.utn.productos.dto.UsuarioResponseDTO;
import com.utn.productos.model.Usuario;
import com.utn.productos.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Transactional
    public Usuario crearUsuario(UsuarioDTO dto) {
        Usuario usuario = new Usuario();
        usuario.setNombre(dto.getNombre());
        usuario.setApellido(dto.getApellido());
        usuario.setMail(dto.getMail());
        usuario.setCelular(dto.getCelular());
        usuario.setContraseña(dto.getContraseña());
        usuario.setRol(dto.getRol());

        return usuarioRepository.save(usuario);
    }

    // Cumple con Criterio C2.3 (Búsqueda por ID)
    @Transactional(readOnly = true)
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));
    }

    // Cumple con Criterio C2.4 (Búsqueda por mail)
    @Transactional(readOnly = true)
    public Usuario buscarPorMail(String mail) {
        return usuarioRepository.findByMail(mail)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con mail: " + mail));
    }

    @Transactional(readOnly = true)
    public UsuarioResponseDTO obtenerPorMail(String mail) {
        Usuario usuario = usuarioRepository.findByMail(mail)
                .orElseThrow(() -> new RuntimeException("No se encontró el usuario con mail: " + mail));

        return UsuarioResponseDTO.fromEntity(usuario);
    }

}
